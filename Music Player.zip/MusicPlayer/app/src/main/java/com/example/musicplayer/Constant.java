package com.example.musicplayer;

public class Constant {
    /**底部导航栏的选项的id
     * @0 发现（随机推荐歌曲等）
     * @1 歌单（发现歌单）
     * @2 我的（收藏的歌单）
     * @3 本地
     * @4 视频
     */
    static int[] itemsDisplayOnTheBottom = {0 , 1 , 2 ,3 ,4};
}
