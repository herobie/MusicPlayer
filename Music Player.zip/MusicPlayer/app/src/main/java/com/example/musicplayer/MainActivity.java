package com.example.musicplayer;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;


public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private BottomNavigationView navigation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    public void initView(){
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null){
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_menu_24);
        }
        //加载底部导航栏的选项
        initBottomNavigation();

    }


    public void initBottomNavigation(){
        navigation = findViewById(R.id.navigation);
        for (int i = 0 ; i < Constant.itemsDisplayOnTheBottom.length ; i++){
            initCustomizeBottomNavigation(Constant.itemsDisplayOnTheBottom[i]);
        }
    }

    public void initCustomizeBottomNavigation(int i){
        switch (i){
            case 0:
                navigation.getMenu().add(0 ,i , 0 , "发现");
                navigation.getMenu().findItem(i).setIcon(R.drawable.ic_baseline_explore_24);
                break;
            case 1:
                navigation.getMenu().add(0 , i , 0 , "歌单");
                navigation.getMenu().findItem(i).setIcon(R.drawable.ic_baseline_queue_music_24);
                break;
            case 2:
                navigation.getMenu().add(0 , i , 0 , "我的");
                navigation.getMenu().findItem(i).setIcon(R.drawable.ic_baseline_music_note_24);
                break;
            case 3:
                navigation.getMenu().add(0 , i , 0 , "本地");
                navigation.getMenu().findItem(i).setIcon(R.drawable.ic_baseline_star_outline_24);
                break;
            case 4:
                navigation.getMenu().add(0 , i , 0 , "视频");
                navigation.getMenu().findItem(i).setIcon(R.drawable.ic_baseline_ondemand_video_24);
        }
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.toolbar , menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.toolbar_search:
                break;
            case android.R.id.home:
                break;
        }
        return true;
    }
}